<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="stylesheet.css">
  <title>Document</title>
</head>
<body>
      <!-- Header section containing announcement and logo -->
      <header>
        <!-- Announcement bar for free shipping -->
        <div class="announcement">
        <p class="announcement-bar">Free Shipping On Orders Of $50 Or More</p>
        </div>
        <!-- Logo and login section -->
        <div class="login">
            <!-- Company logo with a link to the image -->
            <img src="https://simplycandy.com/cdn/shop/files/2_Simply_Candy_Watermark.png?v=1685458139&width=450" alt="logo">
        </div>
    </header>
    
</body>
</html>
