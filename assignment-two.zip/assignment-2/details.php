<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Character encoding for proper rendering of special characters -->
    <meta charset="UTF-8">
    <!-- Responsive design viewport settings -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <!-- Description of the website content for search engines and social media -->
    <meta name="description" content="This website gives information on candy named as simply candy">
    <!-- Keywords relevant to the content of the website, used by search engines -->
    <meta name="keywords" content="candy,Freeze Dried Rainbow Crunchies,Freeze Dried Fruity Twists,Freeze Dried Sour Crunchies">
    <!-- Link to external stylesheet for styling -->
    <link rel="stylesheet" href="stylesheet.css">
    <!-- Link to Font Awesome for additional icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" type="image/x-icon" href="lollipop.png">
    <!-- Title of the webpage displayed in the browser tab -->
    <title>How Sweet Is This! - Simply Candy </title>


    <style>
        /* Add your CSS styles here */
        .container {
            margin-top: 20px;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .btn {
    width: 100px;
    text-align: center;
    display: inline-block;
    padding: 12px 24px; /* Modified padding for a slightly larger button */
    color: white;
    background-color: #70d7d9;
    text-decoration: none;
    border-radius: 8px; /* Modified border-radius for a slightly rounded appearance */
    margin-right: 10px;
    transition: background-color 0.3s ease;
    border: 1px solid #47a1ac; /* Added border for a cleaner look */
    cursor: pointer;
  }

  .btn:hover {
    background-color: #4fb6bb; /* Modified hover color */
  }
    </style>
</head>

<body>
    <!-- Header section containing announcement and logo -->
    <header>
        <!-- Announcement bar for free shipping -->
        <div class="announcement">
        <p class="announcement-bar">Free Shipping On Orders Of $50 Or More</p>
        </div>
        <!-- Logo and login section -->
        <div class="login">
            <!-- Company logo with a link to the image -->
            <img src="https://simplycandy.com/cdn/shop/files/2_Simply_Candy_Watermark.png?v=1685458139&width=450" alt="logo">
        </div>
    </header>
    <main>
        <div class="nav">
            <!-- Navigation section with a list of links -->
            <nav>
                <ul>
                    <li><a href="Index.html">HOME</a></li>
                    <li><a href="Index.html">WHOLESALE</a></li>
                    <li><a href="Index.html">CONTACT US</a></li>
                    <li><a href="Index.html">AFFILIATES</a></li>
                    <li><a href="Index.html">FREEZE DRIED PROCESS</a></li>
                    <li><a href="details.php">USER DETAILS</a></li>
                    <!-- Search bar with input field -->
                    <li class="search-bar">
                        <input type="text" placeholder="Search...">
                    </li>
                    <li>
                        <a href="logout.php">LOGOUT</a>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="container my-4">
    <table class="table">
    <thead>
      <tr>
        <th>ID</th>
        <th>FIRST</th>
        <th>LAST</th>
        <th>USERNAME</th>
        <th>IMAGE</th>
      </tr>
    </thead>
    <tbody>
      <?php
        include "./inc/database.php";
        $sql = "select * from phpadmins";
        $result = $conn->query($sql);
        if(!$result){
          die("Invalid query!");
        }
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            echo "
          <tr>
            <th>{$row['user_id']}</th>
            <td>{$row['first_name']}</td>
            <td>{$row['last_name']}</td>
            <td>{$row['username']}</td>
            <td><img src='{$row['std_img']}' height='200px' width='200px'></td>
            <td>
              <a class='btn btn-success' href='edit.php?user_id={$row['user_id']}'>Edit</a>
              <a class='btn btn-danger' href='delete.php?user_id={$row['user_id']}'>Delete</a>
            </td>
          </tr>
          ";
        }
        ?>
    </tbody>
  </table>
      </div>
    
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>