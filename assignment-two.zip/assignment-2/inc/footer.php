<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="stylesheet.css">
  <title>Document</title>
</head>
<body>
<footer>
    <div class="grid-containers1">
        <div class="grid-items">
            <p>Links</p>
            <ul>
                <li><a href="#">SEARCH</a></li>
                <li><a href="#">FAQ</a></li>
                <li><a href="#">CONTACT US</a></li>
                <li><a href="#">ABOUT US</a></li>
            </ul>
        </div>
        <div class="grid-items">
            <p>
                Our Freeze Dry Candy Is light and airy and full of intense flavor! Once you try it, you will see what the hype is all about!
                <br><br>
                Life is short. Let's make it Sweet!
                <br><br>
                Thank you for choosing Simply Candy!
            </p>
            <div class="email">
            <input type="email" class="email" id="e-mail" name="email" placeholder="Email">
            <input type="submit" class="submit-button" value="Submit">
            </div>
        </div>
        

      </div>
        <div class="footer">
            &copy; 2023, SIMPLY CANDY - SITE DESIGN - ALL RIGHTS RESERVED
        </div>
    </footer>
</body>
</html>
