
<?php
  include "./inc/database.php";
  $user_id="";
  $first_name="";
  $last_name="";
  $username="";

  $error="";
  $success="";

  if($_SERVER["REQUEST_METHOD"]=='GET'){
    if(!isset($_GET['user_id'])){
      header("location:details.php");
      exit;
    }
    $user_id = $_GET['user_id'];
    $sql = "SELECT * FROM phpadmins WHERE user_id = $user_id";
    $result = $conn->query($sql);
    $row = $result->fetch(PDO::FETCH_ASSOC);
    while(!$row){
      header("location:details.php");
      exit;
    }
    $first_name=$row["first_name"];
    $last_name=$row["last_name"];
    $username=$row["username"];
  


  }
  else{
    $user_id = $_POST["user_id"];
    $first_name=$_POST["first_name"];
    $last_name=$_POST["last_name"];
    $username=$_POST["username"];
    $sql = "update phpadmins set first_name='$first_name', last_name='$last_name', username='$username' where user_id='$user_id'";
    $result = $conn->query($sql);
    
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Character encoding for proper rendering of special characters -->
    <meta charset="UTF-8">
    <!-- Responsive design viewport settings -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <!-- Description of the website content for search engines and social media -->
    <meta name="description" content="This website gives information on candy named as simply candy">
    <!-- Keywords relevant to the content of the website, used by search engines -->
    <meta name="keywords" content="candy,Freeze Dried Rainbow Crunchies,Freeze Dried Fruity Twists,Freeze Dried Sour Crunchies">
    <!-- Link to external stylesheet for styling -->
    <link rel="stylesheet" href="stylesheet.css">
    <!-- Link to Font Awesome for additional icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" type="image/x-icon" href="lollipop.png">
    <!-- Title of the webpage displayed in the browser tab -->
    <title>How Sweet Is This! - Simply Candy </title><style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
}

.col-lg-6 {
    width: 50%;
    margin: auto;
}

.card {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    padding: 20px;
    margin-top: 20px;
}

.card-header {
    background-color: #70d7d9;
    color: #fff;
    text-align: center;
    padding: 10px;
    border-radius: 8px 8px 0 0;
}

.form-control {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    box-sizing: border-box;
}

label {
    font-weight: bold;
    font-size: 15px;
}

.btn {
    width: 200px;
    text-align: center;
    display: inline-block;
    padding: 12px 24px; /* Modified padding for a slightly larger button */
    color: white;
    background-color: #70d7d9;
    text-decoration: none;
    border-radius: 8px; /* Modified border-radius for a slightly rounded appearance */
    margin-right: 10px;
    transition: background-color 0.3s ease;
    border: 1px solid #47a1ac; /* Added border for a cleaner look */
    cursor: pointer;
  }

  .btn:hover {
    background-color: #4fb6bb; /* Modified hover color */
  }
  .btn-container {
    text-align: center; /* Center align the content within the container */
  }
  </style>
</head>

<body>
    <!-- Header section containing announcement and logo -->
    <header>
        <!-- Announcement bar for free shipping -->
        <div class="announcement">
        <p class="announcement-bar">Free Shipping On Orders Of $50 Or More</p>
        </div>
        <!-- Logo and login section -->
        <div class="login">
            <!-- Company logo with a link to the image -->
            <img src="https://simplycandy.com/cdn/shop/files/2_Simply_Candy_Watermark.png?v=1685458139&width=450" alt="logo">
        </div>
    </header>
    <main>
        <div class="nav">
            <!-- Navigation section with a list of links -->
            <nav>
                <ul>
                    <li><a href="Index.html">HOME</a></li>
                    <li><a href="Index.html">CONTACT US</a></li>
                    <li><a href="Index.html">AFFILIATES</a></li>
                    <li><a href="Index.html">FREEZE DRIED PROCESS</a></li>
                    <li><a href="details.php">USER DETAILS</a></li>
                    <!-- Search bar with input field -->
                    <li class="search-bar">
                        <input type="text" placeholder="Search...">
                    </li>
                    <li>
                        <a href="logout.php">LOGOUT</a>
                    </li>
                </ul>
            </nav>
        </div>
 <div class="col-lg-6 m-auto">
 
 <form method="post">
 
 <br><br><div class="card">
 
 <div class="card-header bg-warning">
 <h1 class="text-white text-center">  Update Member </h1>
 </div><br>

 <input type="hidden" name="user_id" value="<?php echo $user_id; ?>" class="form-control"> <br>

 <label>First name: </label>
 <input type="text" name="first_name" value="<?php echo $first_name; ?>" class="form-control"> <br>

 <label> Last name: </label>
 <input type="text" name="last_name" value="<?php echo $last_name; ?>" class="form-control"> <br>

 <label> Username </label>
 <input type="text" name="username" value="<?php echo $username; ?>" class="form-control"> <br>

 
 <div class="btn-container">
  <button class="btn btn-success" type="submit" name="submit" href="details.php">Submit</button>
  <a class="btn btn-info" type="submit" name="cancel" href="details.php">Cancel</a>
</div>

 </div>
 </form>
 </div>
</body>
</html>