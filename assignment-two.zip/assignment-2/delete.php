<?php
include "./inc/database.php";

if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Fetch the filename from the database
    $sql = "SELECT std_img FROM phpadmins WHERE user_id = $user_id";
    $result = $conn->query($sql);
    $row = $result->fetch(PDO::FETCH_ASSOC);

    if ($row) {
        $filename = $row['std_img'];

        // Delete the user from the database
        $sql_delete = "DELETE FROM phpadmins WHERE user_id=$user_id";
        $conn->query($sql_delete);

        // Delete the associated image from the folder
        if (file_exists($filename)) {
            unlink($filename);
        } else {
            // Handle the case where the file doesn't exist or can't be deleted
            echo "Image file not found or cannot be deleted.";
        }
    } else {
        // Handle the case where the user_id doesn't exist in the database
        echo "User not found in the database.";
    }
}

header('location:details.php');
exit;
?>